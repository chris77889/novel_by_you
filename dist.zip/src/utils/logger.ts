/**
 * 日志工具 - 根据环境变量控制日志输出
 * 
 * 在开发者模式下显示所有日志
 * 在用户模式下仅显示错误日志
 */

// 检查是否为开发者模式
const isDeveloperMode = (): boolean => {
  // 检查环境变量，确定是否为开发者模式
  return import.meta.env.VITE_DEVELOPER_OPTION === 'true';
};

/**
 * 信息日志 - 仅在开发者模式下显示
 */
export const logInfo = (message: string, ...args: unknown[]): void => {
  if (isDeveloperMode()) {
    console.log(`[信息] ${message}`, ...args);
  }
};

/**
 * 调试日志 - 仅在开发者模式下显示
 */
export const logDebug = (message: string, ...args: unknown[]): void => {
  if (isDeveloperMode()) {
    console.debug(`[调试] ${message}`, ...args);
  }
};

/**
 * 警告日志 - 仅在开发者模式下显示
 */
export const logWarn = (message: string, ...args: unknown[]): void => {
  if (isDeveloperMode()) {
    console.warn(`[警告] ${message}`, ...args);
  }
};

/**
 * 错误日志 - 始终显示
 */
export const logError = (message: string, ...args: unknown[]): void => {
  console.error(`[错误] ${message}`, ...args);
};

// 默认导出所有日志函数
export default {
  isDeveloperMode,
  info: logInfo,
  debug: logDebug,
  warn: logWarn,
  error: logError
}; 
/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_AI_API_KEY: string;
  readonly VITE_AI_CREATIVE_MODEL_NAME: string;
  readonly VITE_AI_CREATIVE_MODEL_ENDPOINT: string;
  readonly VITE_AI_PRECISE_MODEL_NAME: string;
  readonly VITE_AI_PRECISE_MODEL_ENDPOINT: string;
  readonly VITE_AI_BALANCED_MODEL_NAME: string; 
  readonly VITE_AI_BALANCED_MODEL_ENDPOINT: string;
  readonly VITE_DEVELOPER_OPTION: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

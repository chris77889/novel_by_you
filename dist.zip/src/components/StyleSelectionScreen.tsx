import React from 'react';
import { NovelStyle } from '../types';
import StyleCard from './StyleCard';
import LoadingIndicator from './LoadingIndicator';
import * as Dialog from '@radix-ui/react-dialog';
import { Clock, X, LogIn } from 'lucide-react';
import { useNovelStore } from '../store/novelStore';
import { useThemeStore } from './ThemeSwitcher';
import { useAuthStore } from '../store/authStore';
import { useRetryStore } from '../store/retryStore';
import ThemeSwitcher from './ThemeSwitcher';
import AuthModal from './AuthModal';

interface StyleSelectionScreenProps {
  styles: NovelStyle[];
  onSelectStyle: (style: NovelStyle) => void;
  isLoading: boolean;
  error: string | null;
}

const StyleSelectionScreen: React.FC<StyleSelectionScreenProps> = ({ 
  styles, 
  onSelectStyle,
  isLoading,
  error
}) => {
  const histories = useNovelStore((state) => state.histories);
  const theme = useThemeStore((state) => state.theme);
  const { user } = useAuthStore();
  const [showAuthModal, setShowAuthModal] = React.useState(false);
  const { isRetrying, retryCount, maxRetries } = useRetryStore();

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="text-center mb-12 relative">
        <div className="absolute right-0 top-0 flex items-center gap-4">
          {user ? (
            <Dialog.Root>
              <Dialog.Trigger asChild>
                <button
                  className={`p-2 ${
                    theme === 'dark' 
                      ? 'bg-gray-800 hover:bg-gray-700 text-gray-200' 
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                  } rounded-full transition-colors flex items-center gap-2`}
                  aria-label="阅读历史"
                >
                  <Clock className="w-5 h-5" />
                  <span>历史记录</span>
                </button>
              </Dialog.Trigger>
              <Dialog.Portal>
                <Dialog.Overlay className="fixed inset-0 bg-black/50 backdrop-blur-sm" />
                <Dialog.Content className={`fixed right-0 top-0 h-full w-full max-w-md ${
                  theme === 'dark' ? 'bg-gray-900' : 'bg-white'
                } p-6 shadow-xl animate-slide-in-right`}>
                  <div className="flex items-center justify-between mb-6">
                    <Dialog.Title className={`text-xl font-semibold ${
                      theme === 'dark' ? 'text-gray-200' : 'text-gray-800'
                    }`}>阅读历史</Dialog.Title>
                    <Dialog.Close asChild>
                      <button className={`p-2 ${
                        theme === 'dark' ? 'hover:bg-gray-800' : 'hover:bg-gray-100'
                      } rounded-full`} aria-label="关闭">
                        <X className={`w-5 h-5 ${
                          theme === 'dark' ? 'text-gray-200' : 'text-gray-800'
                        }`} />
                      </button>
                    </Dialog.Close>
                  </div>
                  
                  <div className="space-y-4">
                    {histories.length === 0 ? (
                      <p className={`text-center py-8 ${
                        theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                      }`}>暂无阅读历史</p>
                    ) : (
                      histories.map((history) => (
                        <button
                          key={history.id}
                          onClick={() => {
                            onSelectStyle(history.style);
                          }}
                          className={`w-full text-left p-4 ${
                            theme === 'dark' 
                              ? 'bg-gray-800 hover:bg-gray-700 text-gray-200' 
                              : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                          } rounded-lg transition-colors`}
                        >
                          <h3 className="font-medium mb-2">{history.style.name}</h3>
                          <p className={`text-sm ${
                            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                          } line-clamp-2`}>{history.content}</p>
                          <p className={`text-xs ${
                            theme === 'dark' ? 'text-gray-500' : 'text-gray-400'
                          } mt-2`}>
                            {new Date(history.lastUpdated).toLocaleString()}
                          </p>
                        </button>
                      ))
                    )}
                  </div>
                </Dialog.Content>
              </Dialog.Portal>
            </Dialog.Root>
          ) : (
            <button
              onClick={() => setShowAuthModal(true)}
              className={`p-2 ${
                theme === 'dark' 
                  ? 'bg-gray-800 hover:bg-gray-700 text-gray-200' 
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
              } rounded-full transition-colors flex items-center gap-2`}
            >
              <LogIn className="w-5 h-5" />
              <span>登录/注册</span>
            </button>
          )}
          <ThemeSwitcher />
        </div>

        <h1 className={`text-4xl md:text-5xl font-bold mb-4 ${
          theme === 'dark' ? 'text-white' : 'text-gray-900'
        }`}>执笔马良</h1>
        <p className={`text-xl ${
          theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
        } max-w-2xl mx-auto`}>
          选择一种小说风格，开始你的交互式阅读之旅。每个选择都将引领故事走向不同的方向。
        </p>
      </div>

      {error && (
        <div className="bg-red-900/50 border border-red-500 rounded-lg p-4 mb-6 text-red-200 max-w-2xl mx-auto">
          {error}
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center items-center mt-16">
          <LoadingIndicator 
            text={isRetrying ? "连接AI服务中..." : "正在准备您的小说..."} 
            isRetrying={isRetrying}
            retryCount={retryCount}
            maxRetries={maxRetries}
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {styles.map((style) => (
            <StyleCard 
              key={style.id} 
              style={style} 
              onSelect={() => onSelectStyle(style)}
            />
          ))}
        </div>
      )}

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
      />
    </div>
  );
};

export default StyleSelectionScreen;